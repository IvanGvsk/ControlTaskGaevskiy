/*global location history */
sap.ui.define([
	"zjblessons/ControlTaskGaevskiy/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"zjblessons/ControlTaskGaevskiy/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator, MessageBox, MessageToast) {
	"use strict";

	return BaseController.extend("zjblessons.ControlTaskGaevskiy.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");

			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			// keeps the search state
			this._aTableSearchState = [];

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				EditMode: false,
				sObjectGroupID: null
			});
			this.setModel(oViewModel, "worklistView");

			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for worklist's table
				oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			});
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		onNavBack: function() {
			history.go(-1);
		},

		onPressFio: function() {
			MessageBox.information("Гаевский Иван Николаевич");
		},

		onPress: function(oEvent) {
			this._showObject(oEvent);
		},

		_showObject: function(oEvent) {
			debugger
			var MaterialID = oEvent.getParameters().rowBindingContext.getProperty("MaterialID");
			this.getRouter().navTo("object", {
				objectId: MaterialID
			});
		},

		onSearch: function(oEvent) {
			var oTable = this.getView().byId("table");
			var oBinding = oTable.getBinding("rows");
			var oInput = this.getView().byId("searchField");
			oInput.attachChange(function(oEvent) {
				var sFilterValue = oEvent.getParameter("value");
				var oFilter = new sap.ui.model.Filter("MaterialText", sap.ui.model.FilterOperator.Contains, sFilterValue);
				oBinding.filter(oFilter);
			});
		},

		onPressDelete: function(oEvent) {
			debugger
			var oTable = this.byId("table");
			var selectedIndex = oTable.getSelectedIndex();
			var sPath = oTable.getContextByIndex(selectedIndex).sPath;
			var oModel = this.getModel();
			oModel.remove(sPath);
		},

		onPressInfo: function(oEvent) {
			debugger
			var oTable = this.byId("table");
			var selectedIndex = oTable.getSelectedIndex();
			MessageBox.information(oTable.getContextByIndex(selectedIndex).getProperty("MaterialID"));
		},

		onRefresh: function() {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
		 * @private
		 */
		_applySearch: function(aTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(aTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}

	});
});